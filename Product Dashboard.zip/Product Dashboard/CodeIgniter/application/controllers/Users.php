<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

    // public $number;
    // public $password;

	public function index()
	{
        if(!empty($this->session->userdata("user_id")))
        {
		    redirect(base_url("/dashboard"));
        }
        else
        {
            $this->load->view("dashboard/login");
        }  
	}

    public function register()
	{
        if(!empty($this->session->userdata("user_id")))
        {
		    redirect(base_url("/dashboard"));
        }
        else
        {
            $this->load->view("dashboard/register");
        }
	}

    public function create_user()
    {
        $firstName = $this->input->post("firstName", true);
        $lastName = $this->input->post("lastName", true);
        $email = $this->input->post("email", true);
        $password = $this->input->post("password", true);
        $repeat = $this->input->post("repeat", true);
        $data = array(
            "firstName" => $firstName,
            "lastName" => $lastName,
            "email" => $email,
            "password" => $password,
            "repeat" => $repeat
        );
        $this->load->model("User");
        if(empty($this->User->get_all_user()))
        {
            $data["admin"] = 1;
        }
        else
        {
            $data["admin"] = 2;
        }
        $this->User->add_user($data);
        redirect(base_url("/register"));
    }

    public function login()
	{
        if(empty($this->session->userdata("user_id")))
        {
            $email = $this->input->post("email", true);
            $password =  $this->input->post("password", true);
            $this->load->model("User");
            $view_data["data"] = $this->User->get_user($email);
            if(!empty($view_data["data"]) && $password != NULL)
            {
                $encrypted_password = md5($password . "" . $view_data["data"]["salt"]);
                if($view_data["data"]["encrypted_password"] == $encrypted_password)
                {
                    $this->session->set_userdata("user_id", $view_data["data"]["id"]);
                    $this->session->set_userdata("admin", $view_data["data"]["is_admin"]);
                    $this->session->set_userdata("first_name", $view_data["data"]["first_name"]);
                    $this->session->set_userdata("last_name", $view_data["data"]["last_name"]);
                    // $this->session->set_userdata("email", $view_data["data"]["email"]);
                }
                else
                {
                    $error = "Please enter the correct credentials";
                    $this->session->set_userdata("login_error", $error);
                    redirect(base_url("/"));
                }
            }
            else
            {
                $error = "Please enter the correct credentials";
                $this->session->set_userdata("login_error", $error);
                redirect(base_url("/"));
            }
        }
        if(!empty($this->session->userdata("user_id")))
        {
            redirect(base_url("/dashboard"));
        }
        else
        {
            redirect(base_url("/"));
        }
	}
    
    public function profile()
    {
        if(!empty($this->session->userdata("user_id")))
        {
		    $this->load->view('dashboard/profile');
        }
        else
        {
            redirect(base_url("/"));
        }
    }

    public function edit_password()
    {
        $input = $this->input->post(NULL, TRUE);
        $password = $this->input->post("new_password");
        $confirm = $this->input->post("confirm");
        $this->load->model("User");
        $data = $this->User->get_user_by_id($this->session->userdata("user_id"));
        $encrypted_old_password = md5($this->input->post("old_password") . "" . $data["salt"]);
        if($encrypted_old_password == $data["encrypted_password"])
        {
            if($password == $confirm)
            {
                $this->User->edit_password($input, $this->session->userdata("user_id"));
                redirect(base_url("/profile"));
            }
            else
            {
                $error = "Please enter the correct credentials";
                $this->session->set_userdata("change_password", $error);
                redirect(base_url("/profile"));
            }
        }
        else
        {
            $error = "Please enter the correct credentials";
            $this->session->set_userdata("change_password", $error);
            redirect(base_url("/profile"));
        }
    }

    public function edit_details()
    {
        $data = $this->input->post(NULL, TRUE);
        $this->load->model("User");
        $this->User->edit_details($data, $this->session->userdata("user_id"));
        redirect(base_url("/profile"));
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect(base_url("/"));
    }
}
