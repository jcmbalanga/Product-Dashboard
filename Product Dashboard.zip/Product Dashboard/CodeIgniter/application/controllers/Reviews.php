<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reviews extends CI_Controller {

    public function review($product_id)
    {
        $data = $this->input->post();
        $this->load->model("Review");
        $this->Review->add_review($data, $product_id, $this->session->userdata("user_id"));
        redirect(base_url("products/product/{$product_id}"));
    }

    public function reply($product_id, $review_id)
    {
        $data = $this->input->post();
        $this->load->model("Review");
        $this->Review->add_reply($data, $product_id, $review_id, $this->session->userdata("user_id"));
        redirect(base_url("products/product/{$product_id}"));
    }
}