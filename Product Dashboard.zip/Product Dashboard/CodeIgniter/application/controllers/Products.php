<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller {

    public function dashboard()
    {
        if(!empty($this->session->userdata("user_id")))
        {
            $this->load->model("Product");
            $view_data["products"] = $this->Product->get_all_product();
            $this->load->view("dashboard/dashboard", $view_data);
        }
        else
        {
            redirect(base_url("/"));
        }
    }
    
    public function new_product()
    {   
        if(!empty($this->session->userdata("user_id")) && $this->session->userdata("admin") == 1)
        {
            $this->load->view("dashboard/add");
        }
        elseif(!empty($this->session->userdata("user_id")) && $this->session->userdata("admin") == 2)
        {
            redirect(base_url("/dashboard"));
        }
        else
        {
            redirect(base_url("/"));
        }
    }

    public function product($id)
    {
        $this->load->model("Product");
        $view_data["product"] = $this->Product->get_by_id($id);
        $this->load->model("Review");
        $view_data["reviews"] = $this->Review->get_all_reviews($view_data["product"]["id"]);
        $this->load->model("Review");
        $view_data["replies"] = $this->Review->get_all_replies($view_data["product"]["id"]);
        $len_review = 0;
        foreach($view_data["reviews"] as $review)
        {
            if(($review["created_at"] < 60))
            {
                $view_data["reviews"][$len_review]["created_at"] = $view_data["reviews"][$len_review]["created_at"] . " minutes ago";
            }
            elseif($review["created_at"] >= 60)
            {
                $view_data["reviews"][$len_review]["created_at"] = round($view_data["reviews"][$len_review]["created_at"] / 60) . " hours ago"; 
            }
            elseif($review["created_at"] >= 360)
            {
                $view_data["reviews"][$len_review]["created_at"] = round($view_data["reviews"][$len_review]["created_at"]/ 360) . " days ago"; 
            }
            $len_review++;
        }
        $len_reply = 0;
        foreach($view_data["replies"] as $reply)
        {
            if(($reply["created_at"] < 60))
            {
                $view_data["replies"][$len_reply]["created_at"] = $view_data["replies"][$len_reply]["created_at"] . " minutes ago";
            }
            elseif($reply["created_at"] >= 60)
            {
                $view_data["replies"][$len_reply]["created_at"] = round($view_data["replies"][$len_reply]["created_at"] / 60) . " hours ago"; 
            }
            elseif($reply["created_at"] >= 360)
            {
                $view_data["replies"][$len_reply]["created_at"] = round($view_data["replies"][$len_reply]["created_at"]/ 360) . " days ago"; 
            }
            $len_reply++;
        }
        $this->load->view("dashboard/show", $view_data);
    }

    public function add()
    {
        $name = $this->input->post("name", true);
        $description = $this->input->post("description", true);
        $price = $this->input->post("price", true);
        $count = $this->input->post("count", true);
        $data = array(
            "name" => $name,
            "description" => $description,
            "price" => $price,
            "count" => $count,
        );
        $this->load->model("Product");
        $this->Product->add_product($data, $this->session->userdata("user_id"));
        redirect(base_url("/new_product"));
    }

    public function edit($id)
    {
        $this->load->model("Product");
        $view_data["product"] = $this->Product->get_by_id($id);
        $this->load->view("dashboard/edit", $view_data);
    }

    public function change_details($id)
    {
        $data = $this->input->post();
        $this->load->model("Product");
        $this->Product->edit_by_id($data, $id);
        redirect(base_url("/edit/{$id}"));
    }

    public function remove($id)
    {
        $this->load->model("Product");
        $view_data["product"] = $this->Product->get_by_id($id);
        $this->load->view("dashboard/remove", $view_data);
    }

    public function delete($id)
    {
        $this->load->model("Product");
        $this->Product->delete_by_id($id);
        redirect(base_url("/dashboard"));
    }
}
?>