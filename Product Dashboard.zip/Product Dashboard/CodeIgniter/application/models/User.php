<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Model {

    public function get_all_user()
    {
        return $this->db->query("SELECT * FROM users")->result_array();
    }

    public function add_user($data)
    {
        date_default_timezone_set('Asia/Manila');
        $firstName = $data["firstName"];
        $lastName = $data["lastName"];
        $is_admin = $data["admin"];
        $email = $data["email"];
        $password = $data["password"];
        $repeat = $data["repeat"];
        $this->load->library("form_validation");
        $this->form_validation->set_rules("firstName", "first name", "required");
        $this->form_validation->set_rules("lastName", "last name", "required");
        $this->form_validation->set_rules("email", "email", "required|valid_email");
        $this->form_validation->set_rules("password", "password", "required|min_length[8]");
        $this->form_validation->set_rules("repeat", "repeat password", "required|matches[password]");
        if($this->form_validation->run() === FALSE)
        {
            $this->session->set_userdata('errors', validation_errors());
            redirect(base_url("/register"));
        }
        else
        {
            $message = "You've successfully added your details";
            $this->session->set_userdata("message", $message);
            $salt = bin2hex(openssl_random_pseudo_bytes(22));
            $encrypted_password = md5($password . "" . $salt);
            $query = "INSERT INTO users(first_name, last_name, is_admin, email, encrypted_password, salt, created_at, updated_at) VALUES(?,?,?,?,?,?,?,?)";
            $values = array($firstName, $lastName, $is_admin, $email, $encrypted_password, $salt, date('Y-m-d H:i:s'), date('Y-m-d H:i:s'));
            return $this->db->query($query, $values);
        }
    }
    
    public function get_user($email)
    {
        return $this->db->query("SELECT id, first_name, last_name, is_admin, email, encrypted_password, salt FROM users WHERE email = ?", array($email))->row_array();
    }

    public function edit_details($data , $id)
    {
        date_default_timezone_set('Asia/Manila');
        $email = $data["email"];
        $first_name = $data["first_name"];
        $last_name = $data["last_name"];
        $this->load->library("form_validation");
        $this->form_validation->set_rules("email", "email", "required|valid_email");
        $this->form_validation->set_rules("first_name", "first name", "required");
        $this->form_validation->set_rules("last_name", "last name", "required");
        if($this->form_validation->run() === FALSE)
        {
            $this->session->set_userdata('change_details', validation_errors());
            redirect(base_url("/profile"));
        }
        else
        {
            $message_details = "You've successfully changed details";
            $this->session->set_userdata("message_details", $message_details);
            $query = "UPDATE users SET email = ?, first_name = ?, last_name = ?, updated_at = ? WHERE id = ?";
            $values = array($email, $first_name, $last_name, date('Y-m-d H:i:s'), $id);
            return $this->db->query($query, $values);
        }
    }

    public function edit_password($data, $id)
    {
        date_default_timezone_set('Asia/Manila');
        $old = $data["old_password"];
        $password = $data["new_password"];
        $repeat = $data["confirm"];
        $this->load->library("form_validation");
        $this->form_validation->set_rules("old_password", "password", "required");
        $this->form_validation->set_rules("new_password", "password", "required|min_length[8]");
        $this->form_validation->set_rules("confirm", "repeat password", "required|matches[new_password]");
        if($this->form_validation->run() === FALSE)
        {
            $this->session->set_userdata('change_password', validation_errors());
            redirect(base_url("/profile"));
        }
        else
        {
            $message_password = "You've successfully changed details";
            $this->session->set_userdata("message_password", $message_password);
            $salt = bin2hex(openssl_random_pseudo_bytes(22));
            $encrypted_password = md5($password . "" . $salt);
            $query = "UPDATE users SET encrypted_password = ?, salt = ?,updated_at = ? WHERE id = ?";
            $values = array($encrypted_password, $salt, date('Y-m-d H:i:s'), $id);
            return $this->db->query($query, $values);
        }
    }

    public function get_user_by_id($id)
    {
        return $this->db->query("SELECT id, first_name, last_name, is_admin, email, encrypted_password, salt FROM users WHERE id = ?", array($id))->row_array();
    }
}
?>
