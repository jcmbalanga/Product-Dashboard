<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Review extends CI_Model {

    public function get_all_reviews($products_id)
    {
        return $this->db->query("SELECT reviews.id, first_name, last_name, reviews, TIMESTAMPDIFF(minute, reviews.created_at, NOW()) as created_at FROM reviews LEFT JOIN users ON users.id = reviews.users_id WHERE reviews.products_id = $products_id ORDER BY reviews.created_at DESC")->result_array();
    }

    public function add_review($data, $product_id, $user_id)
    {
        date_default_timezone_set('Asia/Manila');
        $review = $data["review"];
        $this->load->library("form_validation");
        $this->form_validation->set_rules("review", "review", "required");
        if($this->form_validation->run() === FALSE)
        {
            $this->session->set_userdata('errors', validation_errors());
            redirect(base_url("products/product/$product_id"));
        }
        else
        {
            $message = "You've successfully added a review";
            $this->session->set_flashdata('message', $message);
            $query = "INSERT INTO reviews(products_id, users_id, reviews, created_at, updated_at) VALUES(?,?,?,?,?)";
            $values = array($product_id, $user_id, $review, date('Y-m-d H:i:s'), date('Y-m-d H:i:s'));
            return $this->db->query($query, $values);
        }
    }

    public function get_all_replies($products_id)
    {
        return $this->db->query("SELECT replies.id, replies.reviews_id, first_name, last_name, comments, TIMESTAMPDIFF(minute, replies.created_at, NOW()) as created_at FROM replies LEFT JOIN users ON users.id = replies.users_id LEFT JOIN reviews ON reviews.id = replies.reviews_id WHERE reviews.products_id = $products_id ORDER BY reviews.created_at DESC")->result_array();
    }

    public function add_reply($data, $product_id, $review_id, $user_id)
    {
        date_default_timezone_set('Asia/Manila');
        $reply = $data["reply"];
        $this->load->library("form_validation");
        $this->form_validation->set_rules("reply", "reply", "required");
        if($this->form_validation->run() === FALSE)
        {
            $this->session->set_flashdata('review_errors', validation_errors());
            redirect(base_url("products/product/$product_id"));
        }
        else
        {
            $message = "You've successfully added a review";
            $this->session->set_flashdata('message_reply', $message);
            $query = "INSERT INTO replies(reviews_id, users_id, comments, created_at, updated_at) VALUES(?,?,?,?,?)";
            $values = array($review_id, $user_id, $reply, date('Y-m-d H:i:s'), date('Y-m-d H:i:s'));
            return $this->db->query($query, $values);
        }
    }
}
?>