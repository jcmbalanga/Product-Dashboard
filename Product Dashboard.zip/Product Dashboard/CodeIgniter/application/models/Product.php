<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Model {

    public function get_all_product()
    {
        return $this->db->query("SELECT * FROM products")->result_array();
    }

    public function add_product($data , $id)
    {
        date_default_timezone_set('Asia/Manila');
        $name = $data["name"];
        $description = $data["description"];
        $price = $data["price"];
        $count = $data["count"];
        $this->load->library("form_validation");
        $this->form_validation->set_rules("name", "product name", "required");
        $this->form_validation->set_rules("description", "description", "required");
        $this->form_validation->set_rules("price", "price", "required");
        $this->form_validation->set_rules("count", "count", "required");
        if($this->form_validation->run() === FALSE)
        {
            $this->session->set_userdata('errors', validation_errors());
            redirect(base_url("products/new_product"));
        }
        else
        {
            $message = "You've successfully added a product.";
            $this->session->set_userdata("message", $message);
            $query = "INSERT INTO products(users_id,name, description, price, quantity, created_at, updated_at) VALUES(?,?,?,?,?,?,?)";
            $values = array($id, $name, $description, $price, $count, date('Y-m-d H:i:s'), date('Y-m-d H:i:s'));
            return $this->db->query($query, $values);
        }
    }

    public function get_by_id($id)
    {
        return $this->db->query("SELECT id, name, price, quantity, sold, description, DATE_FORMAT(created_at, '%M %D %Y') as created_at FROM products WHERE id = ?", array($id))->row_array();
    }

    public function edit_by_id($data, $id)
    {
        $name = $data["name"];
        $description = $data["description"];
        $price = $data["price"];
        $quantity = $data["quantity"];
        $this->load->library("form_validation");
        $this->form_validation->set_rules("name", "product name", "required");
        $this->form_validation->set_rules("description", "description", "required");
        $this->form_validation->set_rules("price", "price", "required");
        if($this->form_validation->run() === FALSE)
        {
            $this->session->set_userdata('errors', validation_errors());
            redirect(base_url("products/edit/{$id}"));
        }
        else
        {
            $message = "You've successfully changed the product";
            $this->session->set_userdata("message", $message);
            $query = "UPDATE products SET name = ?, description = ?, price = ?, quantity = ? WHERE id = ?";
            return $this->db->query($query, array($name, $description, $price, $quantity, $id));
        }
    }

    public function delete_by_id($id)
    {
        return $this->db->query("DELETE FROM products WHERE id = ?", $id);
    }
}