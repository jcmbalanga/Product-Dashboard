<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Authentication</title>
    <link rel="stylesheet" type="text/css" href="/assets/profile.css">
</head>
<body>
    <a href=<?= base_url("/logout")?>>Log Out</a>
    <div>
        <h1>Basic Information</h1>
        <p class="title">First Name:</p>
        <p><?=$first_name?></p>
        <p class="title">Last Name:</p>
        <p><?=$last_name?></p>
        <p class="title">Contact Name:</p>
        <p><?=$contact_number?></p>
        <p class="title">Last Failed Login:</p>
        <p><?=$last_failed_login?></p>
    </div>
</body>
</html>