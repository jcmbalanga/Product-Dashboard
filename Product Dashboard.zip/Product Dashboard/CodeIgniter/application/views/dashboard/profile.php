<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Authentication</title>
    <link rel="stylesheet" type="text/css" href="/assets/header.css">
    <link rel="stylesheet" type="text/css" href="/assets/profile.css">
</head>
<body>
<?php $this->load->view("partials/header") ?>
    <h1>Edit Profile</h1>
    <div>
        <h1>Edit Information</h1>
<?php
if(!empty($this->session->userdata("change_details")))
    {
?>
        <h3 class="error"><?=$this->session->userdata("change_details");?></h3>
<?php
        $this->session->unset_userdata("change_details");
    }
if(!empty($this->session->userdata("message_details")))
    {
?>
        <h3 class="success"><?=$this->session->userdata("message_details");?></h3>
<?php 
        $this->session->unset_userdata("message_details");
    }
?>
        <form action=<?= base_url("/edit_details")?> method="post">
            <p>Email Address:</p>
            <input type="text" name="email">
            <p>First Name:</p>
            <input type="text" name="first_name">
            <p>Last Name:</p>
            <input type="text" name="last_name">
            <input id="submit" type="submit" name="submit" value="Save">
        </form>
    </div>
    <div>
        <h1>Change Password</h1>
<?php
if(!empty($this->session->userdata("change_password")))
    {
?>
        <h3 class="error"><?=$this->session->userdata("change_password");?></h3>
<?php
        $this->session->unset_userdata("change_password");
    }
    if(!empty($this->session->userdata("message_password")))
    {
?>
        <h3 class="success"><?=$this->session->userdata("message_password");?></h3>
<?php 
        $this->session->unset_userdata("message_password");
    }
?>
        <form action=<?= base_url("/edit_password")?> method="post">
            <p>Old Password:</p>
            <input type="password" name="old_password">
            <p> New Password:</p>
            <input type="password" name="new_password">
            <p>Confirm Password:</p>
            <input type="password" name="confirm">
            <input id="submit" type="submit" name="submit" value="Save">
        </form>
    </div>
</body>
</html>