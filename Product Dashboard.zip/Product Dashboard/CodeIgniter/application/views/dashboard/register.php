<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" type="text/css" href="/assets/header.css">
        <link rel="stylesheet" type="text/css" href="/assets/register.css">
    </head>
    <body>
<?php $this->load->view("partials/header") ?>
        <div>
                <h1>Sign up</h1>
<?php
if(!empty($this->session->userdata("errors")))
    {
?>
                <h3 class="error"><?=$this->session->userdata("errors");?></h3>
<?php
        $this->session->unset_userdata("errors");
    }
if(!empty($this->session->userdata("message")))
    {
?>
                <h3 class="success"><?=$this->session->userdata("message");?></h3>
<?php 
                $this->session->unset_userdata("message");
    }
?>
                <form action=<?= base_url("/create_user")?> method="post">
                    <p>Email Address:</p>
                    <input type="text" name="email">
                    <p>First Name:</p>
                    <input type="text" name="firstName">
                    <p>Last Name:</p>
                    <input type="text" name="lastName">
                    <p>Password:</p>
                    <input type="password" name="password">
                    <p>Confirm Password:</p>
                    <input type="password" name="repeat">
                    <input id="submit" type="submit" name="submit" value="Submit">
                </form>
                <a id="login" href=<?=base_url("/")?>>Do you already have an account? Login</a>
            </div>
    </body>
</html>