<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" type="text/css" href="/assets/header.css">
        <link rel="stylesheet" type="text/css" href="/assets/add.css">
    </head>
    <body>
<?php $this->load->view("partials/header") ?>
        <h1>Add a new Product</h1>
        <a class="return" href=<?=base_url("/dashboard")?>>Return to Dashboard</a>
        <form action=<?=base_url("products/add")?> method="post">
<?php if(!empty($this->session->userdata("errors")))
    {
?>
            <h3 class="error"><?=$this->session->userdata("errors");?></h3>
<?php
        $this->session->unset_userdata("errors");
    }
?>
<?php if(!empty($this->session->userdata("message")))
    {
?>
            <h3 class="success"><?=$this->session->userdata("message");?></h3>
<?php
        $this->session->unset_userdata("message");
    }
?>
            <label>Name:<input type="text" name="name"></label>
            <label>Description:<textarea id="description"  name="description"></textarea></label>
            <label>Price:<input type="text" name="price"></label>
            <label>Inventory Count:<input id="count" type="number" name="count" min=0></label>
            <input id="submit" type="submit" name="submit" value="Create">
        </form>
        <?= var_dump($this->session->all_userdata())?>
    </body>
</html>