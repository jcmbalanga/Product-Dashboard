<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" type="text/css" href="/assets/header.css">
        <link rel="stylesheet" type="text/css" href="/assets/remove.css">
    </head>
    <body>
<?php $this->load->view("partials/header") ?>
        <main>
            <h1>Are you sure you want to remove <?=$product["name"] . " (ID #" . $product["id"] . ")?"?></h1>
            <div>
                <a class="no" href=<?=base_url("/dashboard")?>>No</a>
                <a class="yes" href=<?=base_url("products/delete/{$product['id']}")?>>Yes</a>
            </div>
        </main>
        