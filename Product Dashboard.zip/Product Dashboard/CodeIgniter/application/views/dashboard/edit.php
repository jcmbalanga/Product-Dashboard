<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" type="text/css" href="/assets/header.css">
        <link rel="stylesheet" type="text/css" href="/assets/edit.css">
    </head>
    <body>
<?php $this->load->view("partials/header") ?>
        <h1>Edit Product (#<?= $product["id"]?>) (<?= $product["name"]?>)</h1>
        <a class="return" href=<?=base_url("products/dashboard")?>>Return to Dashboard</a>
<?php
if(!empty($this->session->userdata("errors")))
    {
?>
            <h3 class="error"><?=$this->session->userdata("errors");?></h3>
<?php
        $this->session->unset_userdata("errors");
    }
if(!empty($this->session->userdata("message")))
    {
?>
            <h3 class="success"><?=$this->session->userdata("message");?></h3>
<?php
        $this->session->unset_userdata("message");
    }
?>
        <form action=<?= base_url("products/change_details/{$product['id']}")?> method="post">
            <label>Name:<input type="text" name="name" placeholder="Product Name"></label>
            <label>Description:<textarea id="description"  name="description" placeholder="Product Description"></textarea></label>
            <label>Price:<input type="text" name="price" placeholder="Product Price"></label>
            <label>Inventory Count:<input id="count" name="quantity" type="number" min=0></label>
            <input id="submit" type="submit" name="submit" value="Save">
        </form>
    </body>
</html>