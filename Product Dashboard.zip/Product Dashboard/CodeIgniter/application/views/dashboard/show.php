<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" type="text/css" href="/assets/header.css">
        <link rel="stylesheet" type="text/css" href="/assets/show.css">
    </head>
    <body>
<?php $this->load->view("partials/header") ?>
        <main>
            <h1><?= $product["name"]." (P{$product['price']})"?></h1>
            <p>Added since: <?= $product["created_at"]?></p>
            <p>Product ID: #<?= $product["id"]?></p>
            <p>Description: <?= $product["description"]?></p>
            <p>Total sold: <?= ($product["sold"] == NULL) ? "0" : $product["sold"]?></p>
            <p>Number of available stocks: <?= $product["quantity"]?></p>
            <h2>Leave a Review</h2>
            <form action=<?=base_url("reviews/review/{$product['id']}")?> method="post">
                <input type="hidden" name="action" value="review">
                <textarea type="text" name="review" value="review"></textarea>
                <input id="post" type="submit" name="submit" value="Post">
            </form>
            <?php
if(!empty($this->session->userdata("errors")))
    {
?>
                <h3 class="error"><?=$this->session->userdata("errors");?></h3>
<?php
        $this->session->unset_userdata("errors");
    }
if(!empty($this->session->flashdata("message")))
    {
?>
                <h3 class="success"><?=$this->session->userdata("message");?></h3>
<?php 
    }
    foreach($reviews as $review)
    {
?>
            <div class="review">
                <p class="name"><?=ucfirst($review["first_name"]) . " " . ucfirst($review["last_name"])?> wrote:</p>
                <p class="time"><?= $review["created_at"]?></p>
                <p class="message"><?= $review["reviews"]?></p>
            </div>
<?php
        foreach($replies as $reply)
        {
            if($reply["reviews_id"] == $review["id"])
            {
?>
            <div class="reply">
                <p class="name"><?=ucfirst($reply["first_name"]) . " " . ucfirst($reply["last_name"])?> wrote:</p>
                <p class="time"><?= $reply["created_at"]?></p>
                <p class="message"><?= $reply["comments"]?></p>
            </div>
<?php
            }
        }
?>
            <div class="reply">
                <h3>Write a reply</h3>
                <form action=<?=base_url("reviews/reply/{$product['id']}/{$review['id']}")?> method="post">
                    <input type="hidden" name="action" value="reply">
                    <textarea type="text" name="reply" value="reply"></textarea>
                    <input id="reply" type="submit" name="submit" value="Post">
                </form>
            </div>
<?php
    }
?>  
        </main>