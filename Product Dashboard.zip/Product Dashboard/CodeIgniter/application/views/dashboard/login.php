<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" type="text/css" href="/assets/header.css">
        <link rel="stylesheet" type="text/css" href="/assets/login.css">
    </head>
    <body>
<?php $this->load->view("partials/header") ?>
        <div>
            <h1>Log In</h1>
<?php
if(!empty($this->session->userdata("login_error")))
    {
?>
            <h3 class="error"><?=$this->session->userdata("login_error");?></h3>
<?php
        $this->session->unset_userdata("login_error");
    }
?>
            <form action=<?= base_url("/login")?> method="post">
                <p>Email Address:</p>
                <input type="text" name="email">
                <p>Password:</p>
                <input type="password" name="password">
                <input id="submit" type="submit" name="submit" value="Log In">
            </form>
            <a href=<?=base_url("/register")?>>Don't have an account? Register</a>
        </div>
    </body>
</html>