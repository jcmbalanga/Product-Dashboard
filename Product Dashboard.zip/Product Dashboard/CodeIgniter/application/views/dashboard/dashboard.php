<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" type="text/css" href="/assets/header.css">
        <link rel="stylesheet" type="text/css" href="/assets/dashboard.css">
    </head>
    <body>
<?php $this->load->view("partials/header") ?>
<?php 
if(!empty($this->session->userdata("message")))
{
?>
    <p class="success"><?=$this->session->userdata("message")?></p>
<?php   $this->session->unset_userdata("message");
}
    if($this->session->userdata("admin") == 1)
    {
?>
        <h1>Manage Products</h1>
        <a class="add" href=<?=base_url("new_product")?>>Add New</a>
<?php
    }
    else
    {
?>
        <h1>All Products</h1>
<?php
    } 
if(!empty($products))
{
?>
    <table>
        <thead>
            <th>ID</th>
            <th>Name</th>
            <th>Inventory Count</th>
            <th>Quantity Sold</th>
            <th>Price</th>
<?php
    if($this->session->userdata("admin") == 1)
    {
?>
            <th>Actions</th>   
<?php }
?>
        </thead>
<?php
    foreach($products as $product)
    {
?>
        <tbody>
            <tr>
                <td><?=$product["id"]?></td>
                <td><a href=<?=base_url("products/product/{$product['id']}")?>><?=$product["name"]?></a></td>
                <td><?=$product["quantity"]?></td>
                <td><?=($product["sold"] == NULL) ? "0" : $product["sold"] ?></td>
                <td>P<?=$product["price"]?></td>
<?php
        if($this->session->userdata("admin") == 1)
        {
?>
                <td>
                    <a href=<?=base_url("products/edit/{$product['id']}")?>>Edit</a>
                    <a href=<?=base_url("products/remove/{$product['id']}")?>>Remove</a>
                </td>  
<?php   }
?>
            </tr>
        </tbody>
<?php }
?>
    </table>
<?php
}
else
{
?>
        <h2>No products.</h2>
<?php
}
?>
    </body>
</html>