    <header>
        <a id="home" href=<?=base_url("/")?>>V88 Merchandise</a>
        <!-- show when logged in -->
<?php
if(!empty($this->session->userdata("user_id")))
{
?>
        <a class="nav" href=<?=base_url("/dashboard")?>>Dashboard</a>
        <a class="nav" href=<?=base_url("/profile")?>>Profile</a>
        <a class="log" href=<?=base_url("/logout")?>>Log Off</a>
<?php
}
?>
        <!--  -->
        <!-- Show when in log in view -->
        <!-- <a class="log">Register</a> -->
        <!--  -->
        <!-- Show when in register view -->
        <!-- <a class="log">Login</a> -->
        <!--  -->
    </header>
